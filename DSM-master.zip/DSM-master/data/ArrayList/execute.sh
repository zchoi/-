python3 ../../DSM.py --data_dir input_traces --save_dir saved_model --work_dir work_dir
#python3 ../../DSM.py --old_fsm work_dir/FINAL_mindfa.txt --additional_trace work_dir/rejected_traces/ --work_dir 2nd_workdir --save_dir saved_model/
#python3 ../../accuracy_predictor.py --traces input_traces/input.txt  --fsm 2nd_workdir/UPDATED_mindfa.txt --out prediction.txt --verbose
